/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_2;

import java.util.Scanner;
import java.util.Calendar;

public class bai2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        int tuoiMe,tuoiNyc,hieu,nsMe,nsNyc;
        Scanner nhap = new Scanner(System.in);
        System.out.println("Nhập năm sinh của bạn: ");
        tuoiMe = nhap.nextInt();
        System.out.println("Nhập năm sinh của nyc: ");
        tuoiNyc = nhap.nextInt();
        nsMe = (cal.get(Calendar.YEAR)) - tuoiMe;
        nsNyc = (cal.get(Calendar.YEAR)) - tuoiNyc;
        hieu = Math.abs(nsMe-nsNyc);
        System.out.println("Bạn:"+nsMe+" tuổi. Người yêu cũ:"+nsNyc+" tuổi .Cách nhau: "+hieu+" tuổi");
    }
    
}
