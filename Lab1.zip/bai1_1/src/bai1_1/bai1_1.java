/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1_1;
import java.util.Scanner;

public class bai1_1 {
    public static void main(String[] args) {
		Scanner ma = new Scanner(System.in);
		Scanner input = new Scanner(System.in);
		System.out.println("Mời bạn nhập họ và tên: ");
		String tenSV = input.nextLine();
		System.out.println("Mời bạn nhập năm sinh: ");
		int nam = input.nextInt();
		System.out.println("Mời bạn nhập mã sinh viên: ");
		String maSV = ma.nextLine();
		System.out.printf("Chào bạn " + tenSV + " | " + nam + " | " + maSV + " đến với chương trình Java đầu tiên.");

	}
}

