/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1_4;

import java.util.Scanner;

public class bai1_4 {

    public static void main(String[] Args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập vào số: ");
        double a, luyT, kq;
        a = sc.nextDouble();
        System.out.println("Nhập vào luỹ thừa: ");
        luyT = sc.nextDouble();
        kq = Math.pow(a, luyT);
        System.out.println("Ket qua: " + kq + "");
    }
}
