/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_1;

import java.util.Scanner;

public class bai2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double soNghi;
        double diemTB;
        double diemThi;
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập số ngày nghỉ: ");
        soNghi = sc.nextInt();
        System.out.println("Nhập điểm trung bình môn: ");
        diemTB = sc.nextDouble();
        System.out.println("Nhập điểm thi: ");
        diemThi = sc.nextDouble();
        if(soNghi<=4 && diemTB>=5 && diemThi>=5){
            System.out.println("Chúc mừng bạn đã qua môn.");
        }
        else System.out.println("Chúc mừng bạn đã được học lại môn học này.");
        
    }
    
}
