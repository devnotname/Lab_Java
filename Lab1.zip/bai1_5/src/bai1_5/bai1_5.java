/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1_5;

import java.util.Scanner;

public class bai1_5 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Nhập bán kính hình tròn : ");
        final double pi = 3.14;
        double r = input.nextDouble();
        double c = 2 * pi * r;
        double s = pi * r * r;
        System.out.println("Chu vi: " + c + ". Diện tích: " + s + "");
    }
}
